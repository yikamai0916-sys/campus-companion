ALTER TABLE message_localizations ADD COLUMN cache_version INTEGER NOT NULL DEFAULT 1;
